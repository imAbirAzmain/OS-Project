#!/usr/bin/env bash
# =============================================================================
# setup_linux.sh — Ubuntu / Linux Setup & Dependency Installer
#
# Run this script after unzipping the project on Ubuntu / Debian Linux:
#   chmod +x setup_linux.sh
#   ./setup_linux.sh
# =============================================================================
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AZTERM_DIR="${ROOT_DIR}/AzTerm"
CLOUDION_DIR="${ROOT_DIR}/cloudion"

# ANSI Colors
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

printf "${CYAN}"
cat << 'EOF'
=================================================================
       AzTerm & Cloudion — Ubuntu Linux Setup & Diagnostics
=================================================================
EOF
printf "${NC}\n"

# 1. Check Operating System
OS="$(uname -s)"
DISTRO="Linux"
if [[ -f /etc/os-release ]]; then
    DISTRO="$(grep -E '^PRETTY_NAME=' /etc/os-release | cut -d= -f2 | tr -d '"')"
fi
echo "==> Detected OS: $DISTRO ($OS $(uname -m))"

# 2. Check Bash version
BASH_VER_MAJOR="$(echo "$BASH_VERSION" | cut -d. -f1)"
if [[ "$BASH_VER_MAJOR" -lt 3 ]]; then
    printf "${RED}Error: Bash 3.2+ is required. Found: %s${NC}\n" "$BASH_VERSION"
    exit 1
fi
printf "${GREEN}✓ Bash: %s${NC}\n" "$BASH_VERSION"

# 3. Check / configure Node.js and npm
echo
echo "==> Checking Node.js runtime..."
NODE_CMD="$(command -v node || command -v nodejs || true)"

if [[ -z "$NODE_CMD" ]]; then
    printf "${YELLOW}Notice: Node.js was not found in your PATH.${NC}\n"
    echo "Cloudion requires Node.js (v16+) to host the cloud server."
    echo
    if command -v apt-get >/dev/null 2>&1; then
        echo "You can install Node.js and npm using:"
        printf "${CYAN}  sudo apt update && sudo apt install -y nodejs npm curl${NC}\n"
        echo
        read -rp "Would you like to install nodejs and npm now using sudo apt? [y/N]: " INSTALL_APT
        case "$INSTALL_APT" in
            [yY]|[yY][eE][sS])
                echo "Running apt update and install..."
                sudo apt-get update && sudo apt-get install -y nodejs npm curl
                NODE_CMD="$(command -v node || command -v nodejs || true)"
                ;;
            *)
                echo "Skipping automatic installation. Please install Node.js manually."
                ;;
        esac
    fi
fi

if [[ -n "$NODE_CMD" ]]; then
    printf "${GREEN}✓ Node.js found: %s (%s)${NC}\n" "$NODE_CMD" "$($NODE_CMD -v)"
else
    printf "${YELLOW}⚠ Warning: Node.js is still missing. Cloud commands won't start until Node.js is installed.${NC}\n"
fi

if command -v npm >/dev/null 2>&1; then
    printf "${GREEN}✓ npm found: %s${NC}\n" "$(npm -v)"
fi

# 4. Set executable permissions across AzTerm & Cloudion
echo
echo "==> Setting executable permissions on all shell scripts..."
chmod +x "${ROOT_DIR}/setup_linux.sh" 2>/dev/null || true

# AzTerm
if [[ -d "$AZTERM_DIR" ]]; then
    chmod +x "$AZTERM_DIR/azterm.sh" 2>/dev/null || true
    chmod +x "$AZTERM_DIR/install.sh" 2>/dev/null || true
    chmod +x "$AZTERM_DIR/uninstall.sh" 2>/dev/null || true
    chmod +x "$AZTERM_DIR/update.sh" 2>/dev/null || true
    find "$AZTERM_DIR/lib" -name "*.sh" -exec chmod +x {} + 2>/dev/null || true
    find "$AZTERM_DIR/config" -name "*.sh" -exec chmod +x {} + 2>/dev/null || true
    mkdir -p "$AZTERM_DIR/data" "$AZTERM_DIR/scripts"
    touch "$AZTERM_DIR/data/history.txt"
    printf "${GREEN}✓ AzTerm permissions configured${NC}\n"
fi

# Cloudion
if [[ -d "$CLOUDION_DIR" ]]; then
    chmod +x "$CLOUDION_DIR/cloudctl.sh" 2>/dev/null || true
    find "$CLOUDION_DIR/scripts" -name "*.sh" -exec chmod +x {} + 2>/dev/null || true
    mkdir -p "$CLOUDION_DIR/logs" "$CLOUDION_DIR/storage" "$CLOUDION_DIR/backups"
    printf "${GREEN}✓ Cloudion permissions configured${NC}\n"
fi

# 5. Verify & install backend dependencies
echo
echo "==> Verifying Cloudion backend dependencies..."
if [[ -d "${CLOUDION_DIR}/backend" ]]; then
    if [[ ! -d "${CLOUDION_DIR}/backend/node_modules" ]]; then
        if command -v npm >/dev/null 2>&1; then
            echo "Installing backend dependencies via npm..."
            (cd "${CLOUDION_DIR}/backend" && npm install --no-audit --no-fund)
            printf "${GREEN}✓ Dependencies installed successfully${NC}\n"
        else
            printf "${YELLOW}⚠ npm not found. Run 'npm install' in cloudion/backend/ once npm is available.${NC}\n"
        fi
    else
        printf "${GREEN}✓ Backend dependencies are ready (pure JavaScript, cross-platform)${NC}\n"
    fi
fi

# 6. Sanity check scripts
echo
echo "==> Running Cloudion health check..."
if [[ -x "${CLOUDION_DIR}/scripts/cloud/cloud.sh" ]]; then
    INFO_STATUS="$("${CLOUDION_DIR}/scripts/cloud/cloud.sh" info | grep '^STATUS=' | cut -d= -f2 || echo "FAIL")"
    if [[ "$INFO_STATUS" == "SUCCESS" ]]; then
        printf "${GREEN}✓ Cloudion engine is operational${NC}\n"
    else
        printf "${YELLOW}⚠ Cloudion engine reported: %s${NC}\n" "$INFO_STATUS"
    fi
fi

# 7. Local IP Detection
LOCAL_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || ip -4 addr show scope global 2>/dev/null | awk '/inet /{print $2}' | cut -d/ -f1 | head -n 1 || echo "127.0.0.1")"

echo
printf "${CYAN}=================================================================${NC}\n"
printf "${GREEN}       Setup Complete! System is ready on Ubuntu Linux.${NC}\n"
printf "${CYAN}=================================================================${NC}\n"
echo
echo "To use AzTerm and manage Cloudion:"
printf "${YELLOW}  cd AzTerm && ./azterm.sh${NC}\n"
echo "  Inside AzTerm, use:"
echo "    az> cloud start     # Start Cloudion server on port 4000"
echo "    az> cloud status    # Check CPU, RAM, disk and server health"
echo "    az> cloud stop      # Stop Cloudion server"
echo
echo "To manage Cloudion via Terminal Admin CLI:"
printf "${YELLOW}  cd cloudion && ./cloudctl.sh${NC}\n"
echo
echo "To access the Web UI in your browser:"
printf "${CYAN}  Local:   http://localhost:4000${NC}\n"
if [[ -n "$LOCAL_IP" && "$LOCAL_IP" != "127.0.0.1" ]]; then
    printf "${CYAN}  Network: http://%s:4000${NC}\n" "$LOCAL_IP"
fi
echo
