#!/usr/bin/env bash
# =============================================================================
# cloud_start.sh — starts the Cloudion backend server as a background process.
#
# This is the script an integrating terminal (e.g. AzTerm's `cloud start`)
# should exec. It is independently runnable from any shell too.
#
# Usage: cloud_start.sh
# =============================================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../lib/common.sh"

PID_FILE="${PROJECT_ROOT}/.cloudion.pid"
PROCESS_LOG="${LOGS_ROOT}/cloudion_process.log"

if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    die "$EXIT_GENERAL_ERROR" "Cloudion is already running (PID $(cat "$PID_FILE"))"
fi

# Locate Node.js runtime (supports standard 'node' or Debian/Ubuntu 'nodejs')
NODE_BIN="$(command -v node || command -v nodejs || true)"
if [[ -z "$NODE_BIN" ]]; then
    die "$EXIT_GENERAL_ERROR" "Node.js is not installed. Install via: sudo apt update && sudo apt install -y nodejs npm"
fi

if [[ ! -d "${PROJECT_ROOT}/backend/node_modules" ]]; then
    if command -v npm >/dev/null 2>&1; then
        echo "Installing backend dependencies..." >&2
        (cd "${PROJECT_ROOT}/backend" && npm install --no-audit --no-fund) >/dev/null 2>&1 || true
    fi
fi

if [[ ! -d "${PROJECT_ROOT}/backend/node_modules" ]]; then
    die "$EXIT_GENERAL_ERROR" "Backend dependencies not installed — run 'npm install' in backend/ first"
fi

ensure_dir "$LOGS_ROOT" 0750

# ---------------------------------------------------------------------------
# Start Node.js server in a detached background process.
#
# On GNU/Linux: use `setsid` when available to detach into a fresh session,
# ensuring the server stays running even after terminal exits.
# On macOS: use nohup + & disown.
# We capture node's real PID via a wrapper script that writes $$ to the PID
# file before exec-ing node.
# ---------------------------------------------------------------------------
if command -v setsid >/dev/null 2>&1; then
    setsid bash -c "cd '${PROJECT_ROOT}/backend' && echo \$\$ > '${PID_FILE}' && exec '$NODE_BIN' server.js" \
        </dev/null >"${PROCESS_LOG}" 2>&1 &
else
    nohup bash -c "cd '${PROJECT_ROOT}/backend' && echo \$\$ > '${PID_FILE}' && exec '$NODE_BIN' server.js" \
        </dev/null >"${PROCESS_LOG}" 2>&1 &
fi
disown 2>/dev/null || true

sleep 1

if ! kill -0 "$(cat "$PID_FILE" 2>/dev/null)" 2>/dev/null; then
    rm -f "$PID_FILE"
    last_err="$(tail -n 2 "${PROCESS_LOG}" 2>/dev/null | tr '\n' ' ' | sed 's/[[:space:]]*$//' || true)"
    if [[ -n "$last_err" ]]; then
        die "$EXIT_GENERAL_ERROR" "Cloudion failed to start: ${last_err}"
    else
        die "$EXIT_GENERAL_ERROR" "Cloudion failed to start — see logs/cloudion_process.log"
    fi
fi

pid="$(cat "$PID_FILE")"
log_event server CLOUD_START system "pid=${pid}"

emit STATUS SUCCESS
emit CODE "$EXIT_SUCCESS"
emit MESSAGE "Cloudion started"
emit PID "$pid"
exit "$EXIT_SUCCESS"
