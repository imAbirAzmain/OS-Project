#!/bin/bash

############################################################
# AzTerm v2 Installation Script
############################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo
echo "=========================================="
echo "      AzTerm v2 Installation"
echo "=========================================="
echo

# Check Bash version
BASH_VERSION_MAJOR=$(echo $BASH_VERSION | cut -d. -f1)
if [[ $BASH_VERSION_MAJOR -lt 3 ]]; then
    echo "Error: Bash 3.2+ required. Your version: $BASH_VERSION"
    exit 1
fi

echo "✓ Bash version: $BASH_VERSION"
echo

# Make scripts executable
echo "Making AzTerm scripts executable..."
chmod +x "$SCRIPT_DIR/azterm.sh"
chmod +x "$SCRIPT_DIR/install.sh"
chmod +x "$SCRIPT_DIR/uninstall.sh"
chmod +x "$SCRIPT_DIR/update.sh"
chmod +x "$SCRIPT_DIR/lib/"*.sh
chmod +x "$SCRIPT_DIR/config/"*.sh

# Also ensure sibling Cloudion scripts are executable if present
CLOUDION_DIR="${SCRIPT_DIR%/*}/cloudion"
if [[ -d "$CLOUDION_DIR" ]]; then
    echo "Configuring Cloudion script permissions..."
    chmod +x "$CLOUDION_DIR/cloudctl.sh" 2>/dev/null || true
    find "$CLOUDION_DIR/scripts" -name "*.sh" -exec chmod +x {} + 2>/dev/null || true
    echo "✓ Cloudion scripts configured"
fi

echo "✓ Scripts are executable"
echo

# Check Node.js and dependencies for Cloudion integration
echo "Checking Cloudion backend dependencies..."
NODE_CMD="$(command -v node || command -v nodejs || true)"
if [[ -n "$NODE_CMD" ]]; then
    echo "✓ Node.js detected: $($NODE_CMD -v)"
else
    echo "Notice: Node.js was not found in PATH."
    echo "  On Ubuntu Linux, install via:"
    echo "    sudo apt update && sudo apt install -y nodejs npm"
fi

if [[ -d "$CLOUDION_DIR/backend" ]]; then
    if [[ ! -d "$CLOUDION_DIR/backend/node_modules" ]]; then
        if command -v npm >/dev/null 2>&1; then
            echo "Installing Cloudion backend dependencies..."
            (cd "$CLOUDION_DIR/backend" && npm install --no-audit --no-fund) || true
        else
            echo "  Run 'npm install' in cloudion/backend once npm is installed."
        fi
    else
        echo "✓ Cloudion backend dependencies are present"
    fi
fi
echo

# Create data directory if it doesn't exist
if [[ ! -d "$SCRIPT_DIR/data" ]]; then
    echo "Creating data directory..."
    mkdir -p "$SCRIPT_DIR/data"
    echo "✓ Data directory created"
else
    echo "✓ Data directory exists"
fi

# Initialize history file if it doesn't exist
if [[ ! -f "$SCRIPT_DIR/data/history.txt" ]]; then
    echo "Initializing history file..."
    touch "$SCRIPT_DIR/data/history.txt"
    echo "✓ History file created"
else
    echo "✓ History file exists"
fi

# Create scripts directory if it doesn't exist
if [[ ! -d "$SCRIPT_DIR/scripts" ]]; then
    echo "Creating scripts directory..."
    mkdir -p "$SCRIPT_DIR/scripts"
    echo "✓ Scripts directory created"
else
    echo "✓ Scripts directory exists"
fi

echo
echo "=========================================="
echo "    Installation Completed Successfully"
echo "=========================================="
echo
echo "To start AzTerm, run:"
echo "  $SCRIPT_DIR/azterm.sh"
echo
echo "For help, run:"
echo "  ./azterm.sh"
echo "  az:~> help"
echo
